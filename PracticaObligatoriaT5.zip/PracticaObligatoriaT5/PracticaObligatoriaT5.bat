@echo off
java -jar PracticaObligatoriaT5.jar
pause